﻿namespace web_app_domain
{
    public class Produto
    {
        public int ID { get; set; }
        public string Nome { get; set; }
        public string Preco { get; set; }
        public int Quantidade_Estoque { get; set; }
        public string Data_Criacao { get; set; }

    }
}
